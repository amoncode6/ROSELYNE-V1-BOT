# Roselyne v1 - WhatsApp Bot

**Roselyne v1** is a Baileys-based WhatsApp bot with a control panel, session-based login, and multiple automation features.

## Features
- Auto Status
- Auto Bio
- Anti Delete
- Anti View Once
- Anti Edit
- Auto React
- Web Panel for control

## Setup
1. Deploy to [Render.com](https://render.com)
2. Add session folder (after pairing)
3. Use `.menu` in chat to see options

## Owner
- Number: +254759006509
